#!/usr/bin/env bash

SLACK_URL=$(aws secretsmanager get-secret-value --secret-id arn:aws:secretsmanager:ap-southeast-2:992517041113:secret:/paynow/mobility/slack/mobility-platform-events/webhook --query SecretString --output text)
DATE=`date`
MESSAGE=`cat <<EOF
{
    "blocks": [
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": "*<$BUILDKITE_BUILD_URL|Exporting dev and QA RDS data>*\nThis will overwrite existing *S3 stored* RDS data\n$DATE"
            },
            "accessory": {
                "type": "image",
                "image_url": "https://buildkite.com/_next/static/assets/assets/images/brand-assets/buildkite-logo-portrait-on-light-61fc0230.png",
                "alt_text": "buildkite"
            }
        },
        {
            "type": "divider"
        },
        {
            "type": "actions",
            "elements": [
                {
                    "type": "button",
                    "text": {
                        "type": "plain_text",
                        "text": ":inbox_tray: Export RDS data",
                        "emoji": true
                    },
                    "url": "https://buildkite.com/afterpay-ops/mobility-ecs-platform-migrate-rds-export"
                },
                {
                    "type": "button",
                    "text": {
                        "type": "plain_text",
                        "text": ":outbox_tray: Import RDS data",
                        "emoji": true
                    },
                    "url": "https://buildkite.com/afterpay-ops/mobility-ecs-platform-migrate-rds-import"
                }
            ]
        },
        {
            "type": "actions",
            "elements": [
                {
                    "type": "button",
                    "text": {
                        "type": "plain_text",
                        "text": ":floppy_disk: Visit dev RDS S3 bucket",
                        "emoji": true
                    },
                    "url": "https://s3.console.aws.amazon.com/s3/buckets/atg-buildkite-artifacts-paynow-dev?region=ap-southeast-2&prefix=exports/rds/"
                },
                {
                    "type": "button",
                    "text": {
                        "type": "plain_text",
                        "text": ":floppy_disk: Visit QA RDS S3 bucket",
                        "emoji": true
                    },
                    "url": "https://s3.console.aws.amazon.com/s3/buckets/atg-buildkite-artifacts-paynow-qa?region=ap-southeast-2&prefix=exports/rds/"
                }
            ]
        }
    ]
}
EOF
`

echo $MESSAGE

curl -L $SLACK_URL \
    -X POST \
    -H 'Content-type: application/json' \
    --data "${MESSAGE}"
