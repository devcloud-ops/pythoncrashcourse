
#!/usr/bin/env bash
set -eo pipefail

cat << EOF | buildkite-agent annotate --style "info"
  **Artifact Version**: ${ARTIFACT_VERSION}

  **Docker Tag**: ${TAG}
EOF
