import mysql.connector as mysql
import os
import boto3
import logging
import string
import secrets
import json

PASS_LEN = 28


def lambda_handler(event, context):
    logging.getLogger().setLevel(logging.DEBUG)
    logger = logging.getLogger()

    databases = {}
    ssm_path = os.environ['APPLICATION_SSM_PATH']
    stack = os.environ['STACK_SHORTNAME']

    if 'non-pci' in stack:
        with open('schemas-non-pci.json') as schema:
            databases = json.load(schema)
    else:
        with open('schemas-pci.json') as schema:
            databases = json.load(schema)

    ssm = boto3.client('ssm')

    def create_ssm_username(
            svc_name,
            stack_name,
            username,
            ssm_root_path,
            overwrite=False):
        try:
            ssm.put_parameter(
                Name=f'{ssm_root_path}/{stack_name}/{svc_name}/database/username',
                Value=username,
                Type='String',
                Overwrite=overwrite
            )
        except BaseException:
            logger.warn(f'{ssm_root_path}/{stack_name}/{svc_name}/database/username already exists')

    def create_ssm_password(
            svc_name,
            stack_name,
            ssm_root_path,
            overwrite=False):
        allowed_chars = string.ascii_letters + string.digits
        password = ''.join(secrets.choice(allowed_chars)
                           for i in range(PASS_LEN))
        try:
            ssm.put_parameter(
                Name=f'{ssm_root_path}/{stack_name}/{svc_name}/database/password',
                Value=password,
                Type='SecureString',
                Overwrite=overwrite
            )
        except BaseException:
            logger.error(f'{ssm_root_path}/{stack_name}/{svc_name}/database/password already exists')
            password = get_ssm_value(f'{ssm_root_path}/{stack_name}/{svc_name}/database/password', True)
        return password

    def get_ssm_value(name, decrypt=False):
        return ssm.get_parameter(
            Name=name,
            WithDecryption=decrypt
        )['Parameter']['Value']

    try:
        endpoint = os.environ['DB_ENDPOINT']

        if ':' in endpoint:
            endpoint = endpoint.split(':')[0]
        username = get_ssm_value(os.environ['DB_USERNAME'])
        password = get_ssm_value(os.environ['DB_PASSWORD'], True)
    except BaseException:
        logger.error('Parameter not found')
        sys.exit()

    logger.debug(f'Endpoint:{endpoint} Username:{username} Password:{password}')
    db = mysql.connect(
        host=endpoint,
        user=username,
        password=password
    )

    cursor = db.cursor()
    cursor.execute("select user from mysql.user")
    existing_users = set(x.decode() for x, in cursor.fetchall())
    logger.info(f'Existing users {existing_users}')
    for svc, schemas in databases.items():
        for schema in schemas:
            database = schema['schema']
            database_user = schema['username']
            logger.info(f'Service {svc} Database {database} Database User {database_user}')
            if database_user not in existing_users:
                create_ssm_username(
                    svc,
                    stack,
                    database_user,
                    ssm_path)
                password = create_ssm_password(
                    svc, stack, ssm_path)
                logger.info(f'Creating user {database_user} with password {password}')
                cursor.execute(f"CREATE USER '{database_user}'@'%'")
                cursor.execute(f"SET PASSWORD FOR '{database_user}'@'%' = PASSWORD('{password}')")
                logger.info(f'Adding {database_user} to the existing users')
                existing_users.add(database_user)
            try:
                logger.info(f'Creating database {database}')
                cursor.execute(f"CREATE DATABASE {database}")
            except BaseException:
                logger.error(f'{database} already exists')
            logger.info(f'Granting user {database_user} privileges to {database}')
            cursor.execute(f"GRANT ALL PRIVILEGES ON {database}.* TO '{database_user}'@'%'")
            cursor.execute(f"FLUSH PRIVILEGES")
    db.close()
