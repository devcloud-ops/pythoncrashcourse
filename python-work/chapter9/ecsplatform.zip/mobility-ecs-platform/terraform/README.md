# Terraform

## Structure

Creating new services should be done at the root module with increments.

```bash
# {increment}-{service}.tf

00-variables.tf
01-driver.tf
02-modules.tf
03-topaz.tf
...
```

### Common Terraform Module - `/terraform/common`

*Planned* to be moved into `paynow-terraform-modules` and versioned similar to [afterpay-terraform-modules](https://github.com/AfterpayTouch/afterpay-terraform-modules).

### Microservice Terraform Module - `/terraform/microservice`

*Planned* to be moved into `paynow-terraform-modules` and versioned similar to [afterpay-terraform-modules](https://github.com/AfterpayTouch/afterpay-terraform-modules).

## Development

Use this Makefile for deployments from local machines.

```bash
# Select the terraform version used by the project (Refer. https://tfswitch.warrensbox.com/)
make install

# Apply Terraform changes
export CONFIG=dev
make apply

# Or inline config
CONFIG=dev make apply
```

## Backend

Backend state is controlled in an S3 bucket access at the `paynow-buildfactory-admin` account with IAM permissions **on the S3 bucket** shared to other accounts such as `paynow-dev-admin` and `paynow-prod-admin`.
