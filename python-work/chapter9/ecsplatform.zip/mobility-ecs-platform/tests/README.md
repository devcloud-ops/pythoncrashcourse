# Mobility ECS Platform Tests

End-to-end tests to run against the ECS environments.

## Running Tests

### Docker

```bash
# Install packages
npm ci

# dev, qa, uat, prod
export CONFIG=dev

# Run tests per environment
docker-compose run --rm tests
```

### Locally

```bash
# Install packages
npm ci

# dev, qa, uat, prod
export CONFIG=dev

# Open Cypress to run tests from the UI (dev)
npm run ui

# Or run tests per environment
npm run test
```

## Debugging

If we're using VSCode to debug, we need to listen to Chrome upon running tests. Add this to the project `.vscode/launch.json`.

```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "type": "chrome",
      "request": "attach",
      "name": "Attach to Cypress Chrome",
      "port": 9222,
      "urlFilter": "http://localhost*",
      "webRoot": "${workspaceFolder}",
      "sourceMaps": true,
      "skipFiles": [
        "cypress_runner.js",
      ],
    },
  ]
}
```

Run the following command to open Cypress and run tests while listening to the Chrome instance via VSCode.

- Be sure to open the browser via running a test from the UI to begin listening
- Use breakpoints, inspect element and `debugger` keywords to debug
