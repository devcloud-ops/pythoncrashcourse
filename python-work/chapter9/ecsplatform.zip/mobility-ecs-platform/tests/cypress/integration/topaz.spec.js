const { parseStringPromise } = require("xml2js");

context("Topaz", () => {
  const topazEndpoint = Cypress.config("topazEndpoint");
  it("ping", () => {
    cy.request(`https://${topazEndpoint}/optus-adaptor/pingTopazCore`).then(
      (response) => {
        assert.equal(response.status, 200);
      }
    );
  });

  it("activation", () => {
    let traceId = "";

    cy.request({
      url: `https://${topazEndpoint}/optus-adaptor/activation/start`,
      method: "post",
      headers: {
        "Content-Type": "application/xml",
      },
      body: `
      <ActivationStartRequest>
        <reference>3J93D7K34987D5K93D987K3DD43</reference>
        <transactionType>AUTHENTICATE</transactionType>
        <brand>OPTUS</brand>
        <channel>SELFSERVE</channel>
        <accessMethod>ONLINE</accessMethod>
        <customer>
          <firstName>John</firstName>
          <lastName>Citizen</lastName>
          <dateOfBirth>19990625</dateOfBirth>
          <businessName>Touchcorp</businessName>
          <businessNumber>0391234567</businessNumber>
        <emailAddress>someone@where.com</emailAddress>
          <address>
            <unformatted>16/380 Latrobe Street MELBOURNE VIC 3000</unformatted>
          </address>
        </customer>
        <plan>
        <spid>200</spid>
        <planName>My Prepaid Daily</planName>
        <tariffId>200106</tariffId>
        <amount></amount>
        <uvVal></uvVal>
      </plan>
      <voucherNumber></voucherNumber>
      <serviceDetails>
        <simNumber>77666655555</simNumber>
        <MSN>0401200106</MSN>
      </serviceDetails>
      <preLoadedCredit>0</preLoadedCredit>
      <successURL>https://${topazEndpoint}/success</successURL>
      <errorURL>https://${topazEndpoint}/error</errorURL>
      </ActivationStartRequest>
      `,
    })
      .then((response) => {
        assert.equal(response.status, 200);

        return parseStringPromise(response.body);
      })
      .then((response) => {
        assert.equal(response.ActivationStartResponse.resultCode[0], "0");

        traceId = response.ActivationStartResponse.OTID[0];
        return cy.request({
          url: `https://${topazEndpoint}/optus-adaptor/activation/enquire`,
          method: "post",
          headers: {
            "Content-Type": "application/json",
          },
          body: { traceId: traceId },
        });
      })
      .then((response) => {
        return cy.request({
          url: `https://${topazEndpoint}/optus-adaptor/activation/verification`,
          method: "post",
          body: `
          <ActivationVerificationRequest org="Optus" tid="${traceId}">
            <OTID>${traceId}</OTID>
          </ActivationVerificationRequest>
          `,
        });
      })
      .then((response) => {
        assert.equal(response.status, 200);

        return parseStringPromise(response.body);
      })
      .then((response) => {
        assert.equal(
          response.OnlineActivationVerifyIdentityResponse.resultCode[0],
          "0"
        );

        return cy.request({
          url: `https://${topazEndpoint}/optus-adaptor/activation/setup/cc`,
          method: "post",
          headers: {
            "Content-Type": "application/json",
          },
          body: {
            traceId: traceId,
            rechargeAmount: "20.00",
            paymentAmount: "20.00",
            voucherType: "200",
            cardNumber: "4624855424099351",
            cardHolderName: "Dr. Will Robinson",
            cardExpiryMonth: "06",
            cardExpiryYear: "26",
            cardSecurityCode: "123",
            storeToken: "true",
            createAutoPay: "false",
            autoPeriodType: "null",
            autoPeriodCount: "null",
            emailAddr: "null",
          },
        });
      })
      .then((response) => {
        assert.equal(response.status, 200);
        assert.equal(response.body.resultCode, "0");

        return cy.request({
          url: `https://${topazEndpoint}/optus-adaptor/activation/confirm`,
          method: "post",
          headers: {
            "Content-Type": "application/xml",
          },
          body: `
          <ActivationConfirmRequest org="Optus" tid="${traceId}">
          <OTID>${traceId}</OTID>
            <activationSuccess>Y</activationSuccess>
            <description>Service ported</description>
          </ActivationConfirmRequest>
          `,
        });
      })
      .then((response) => {
        assert.equal(response.status, 200);

        return parseStringPromise(response.body);
      })
      .then((response) => {
        assert.equal(response.ActivationConfirmResponse.resultCode[0], "0");
        assert.equal(
          response.ActivationConfirmResponse.rechargeOutcome[0],
          "SUCCESS"
        );
      });
  });

  it("online recharge with credit card", () => {
    let traceId = "";

    cy.request({
      url: `https://${topazEndpoint}/optus-adaptor/optus/online/start`,
      method: "post",
      form: true,
      headers: {
        "X-Topaz-Device-ID": `{ "deviceId": "DEV-123" }`,
      },
      body: {
        PM: "CC",
        MSISDN: "0401200106",
        SRURL: `https://${topazEndpoint}/optus-adaptor/success`,
        EURL: `https://${topazEndpoint}/optus-adaptor/failure`,
      },
    })
      .then((response) => {
        assert.equal(response.status, 200);
        assert.isFalse(response.body.includes("Failure"), "Topaz request should not return the error page");
      })
      .then((response) => {
        return parseStringPromise(response.body);
      })
      .then((response) => {
        traceId = response.html.body[0].table[0].tr[4].td[1];

        return cy.request({
          url: `https://${topazEndpoint}/optus-adaptor/optus/online/cc/setup`,
          method: "post",
          form: true,
          headers: {
            "X-Topaz-Device-ID": `{ "deviceId": "DEV-123" }`,
          },
          body: {
            OTID: traceId,
            PA: "30.00",
            VT: "123",
            UT: "N",
            CCN: "4111111111111111",
            CT: "VISA",
            CEM: "06",
            CEY: "26",
            SC: "123",
            CH: "John",
            ST: "Y",
            AP: "N",
            APPT: "DAY",
            APPC: "10",
            EM: "john.doe@afterpaytouch.com",
            EM2: "john.doe@afterpaytouch.com",
            RA: "30.00",
            SRURL: `https://${topazEndpoint}/optus-adaptor/success`,
            EURL: `https://${topazEndpoint}/optus-adaptor/failure`,
          },
        });
      })
      .then((response) => {
        assert.equal(response.status, 200);
        assert.isFalse(response.body.includes("Failure"), "Topaz request should not return the error page");
      });
  });

  it("online recharge with voucher", () => {
    let traceId = "";

    cy.request({
      url: `https://${topazEndpoint}/optus-adaptor/optus/online/start`,
      method: "post",
      form: true,
      headers: {
        "X-Topaz-Device-ID": `{ "deviceId": "DEV-123" }`,
      },
      body: {
        PM: "VOUCHER",
        MSISDN: "0401200106",
        SRURL: `https://${topazEndpoint}/optus-adaptor/success`,
        EURL: `https://${topazEndpoint}/optus-adaptor/failure`,
      },
    })
      .then((response) => {
        assert.equal(response.status, 200);
        assert.isFalse(response.body.includes("Failure"), "Topaz request should not return the error page");
      })
      .then((response) => {
        return parseStringPromise(response.body);
      })
      .then((response) => {
        traceId = response.html.body[0].table[0].tr[3].td[1];

        return cy.request({
          url: `https://${topazEndpoint}/optus-adaptor/optus/online/voucher/setup`,
          method: "post",
          form: true,
          headers: {
            "X-Topaz-Device-ID": `{ "deviceId": "DEV-123" }`,
          },
          body: {
            OTID: traceId,
            VN: "1010000000",
            SRURL: `https://${topazEndpoint}/optus-adaptor/success`,
            EURL: `https://${topazEndpoint}/optus-adaptor/failure`,
          },
        });
      })
      .then((response) => {
        assert.equal(response.status, 200);
        assert.isFalse(response.body.includes("Failure"), "Topaz request should not return the error page");

        return cy.request({
          url: `https://${topazEndpoint}/optus-adaptor/optus/online/voucher/confirm`,
          method: "post",
          form: true,
          headers: {
            "X-Topaz-Device-ID": `{ "deviceId": "DEV-123" }`,
          },
          body: {
            OTID: traceId,
            SRURL: `https://${topazEndpoint}/optus-adaptor/success`,
            EURL: `https://${topazEndpoint}/optus-adaptor/failure`,
          },
        });
      })
      .then((response) => {
        assert.equal(response.status, 200);
        assert.isFalse(response.body.includes("Failure"), "Topaz request should not return the error page");
      });
  });

  it("moa recharge using credit card", () => {
    let traceId = "";

    cy.request({
      url: `https://${topazEndpoint}/optus-adaptor/optus/mscapp/start`,
      method: "post",
      body: `
      <MSCAppStartRequest>
        <sourceMSN></sourceMSN>
        <sourceUID/>
        <rechargeMSN>61401200110</rechargeMSN>
        <APN>N</APN>
        <rechargeAmount>10</rechargeAmount>
        <voucherCode></voucherCode>
        <applicationType>Tablet</applicationType>
        <applicationUID>AW2QIOQOOEQE2323434JHHS190-DH</applicationUID>
        <paymentAmount/>
        <upliftType/>
        <upliftAmount/>
        <upliftPartition/>
        <upliftExpiry/>
      </MSCAppStartRequest>
      `,
    })
      .then((response) => {
        assert.equal(response.status, 200);

        return parseStringPromise(response.body);
      })
      .then((response) => {
        traceId = response.MSCAppStartResponse.traceID[0];
        assert.isNotEmpty(traceId, "Trace ID should exist")

        return cy.request({
          url: `https://${topazEndpoint}/optus-adaptor/optus/mscapp/setup`,
          method: "post",
          body: `
          <MSCAppSetupRequest>
            <traceID>${traceId}</traceID>
            <useToken>N</useToken>
            <cardHolderName>abc</cardHolderName>
            <cardNumber>4024007145508973</cardNumber>
            <cardExpiryMonth>04</cardExpiryMonth>
            <cardExpiryYear>24</cardExpiryYear>
            <cardSecurityCode>101</cardSecurityCode>
            <storeToken>N</storeToken>
          </MSCAppSetupRequest>
          `,
        });
      })
      .then((response) => {
        assert.equal(response.status, 200);

        return cy.request({
          url: `https://${topazEndpoint}/optus-adaptor/optus/mscapp/confirm`,
          method: "post",
          timeout: 120000,
          body: `
          <MSCAppConfirmRequest>
            <traceID>${traceId}</traceID>
          </MSCAppConfirmRequest>
          `,
        });
      })
      .then((response) => {
        assert.equal(response.status, 200);
      });
  });
});
