USE `topaz`;

UPDATE `topaz_host` SET `PRIMARY_URL` = 'http://mock:8084/eProxy/WsgRealTimeBillingService' WHERE (`SHORT_NAME` = 'PPIN');
UPDATE `topaz_host` SET `PRIMARY_URL` = 'http://mock:8084/eProxyVoucherEnq/WsgVoucherService' WHERE (`SHORT_NAME` = 'VOUCHER-ENQUIRY');
UPDATE `topaz_host` SET `PRIMARY_URL` = 'http://mock:8084/eProxyVoucherRch/UVRechargeService' WHERE (`SHORT_NAME` = 'VOUCHER-RECHARGE');
UPDATE `topaz_host` SET `PRIMARY_URL` = 'http://mock:8084/pxaccess/pxa2a.aspx' WHERE (`SHORT_NAME` = 'A2A');
UPDATE `topaz_host` SET `PRIMARY_URL` = 'http://mock:8084/WS/PXWS.asmx' WHERE (`SHORT_NAME` = 'DPS-OPTUS');
UPDATE `topaz_host` SET `PRIMARY_URL` = 'http://mock:8084/WS/PXWS.asmx' WHERE (`SHORT_NAME` = 'DPS-BOOST');
UPDATE `topaz_host` SET `PRIMARY_URL` = 'http://mock:8084/WS/PXWS.asmx' WHERE (`SHORT_NAME` = 'DPS-VMA PRE-PAID');
UPDATE `topaz_host` SET `PRIMARY_URL` = 'http://mock:8084/WS/PXWS.asmx' WHERE (`SHORT_NAME` = 'DPS-COLES MOBILE');
UPDATE `topaz_host` SET `PRIMARY_URL` = 'http://mock:8084/WS/PXWS.asmx' WHERE (`SHORT_NAME` = 'DPS-GOMO');
UPDATE `topaz_host` SET `PRIMARY_URL` = 'http://mock:8084/WS/PXWS.asmx' WHERE (`SHORT_NAME` = 'DPS-GOMO-SHOP');
UPDATE `topaz_host` SET `PRIMARY_URL` = 'http://mock:8084/WS/PXWS.asmx' WHERE (`SHORT_NAME` = 'DPS-OPTUS-SHOP');
UPDATE `topaz_host` SET `PRIMARY_URL` = 'http://mock:8084/payment/ctpe/' WHERE (`SHORT_NAME` = 'SIMPLEPAY-OPTUS');
UPDATE `topaz_host` SET `PRIMARY_URL` = 'http://mock:8084/payment/ctpe/' WHERE (`SHORT_NAME` = 'SIMPLEPAY-COLES MOBILE');
UPDATE `topaz_host` SET `PRIMARY_URL` = 'http://mock:8084/payment/ctpe/' WHERE (`SHORT_NAME` = 'SIMPLEPAY-GOMO');
UPDATE `topaz_host` SET `PRIMARY_URL` = 'http://mock:8084/payment/ctpe/' WHERE (`SHORT_NAME` = 'SIMPLEPAY-GOMO-SHOP');
UPDATE `topaz_host` SET `PRIMARY_URL` = 'http://mock:8084/payment/ctpe/' WHERE (`SHORT_NAME` = 'SIMPLEPAY-OPTUS-SHOP');
UPDATE `topaz_host` SET `PRIMARY_URL` = 'http://mock:8084/tornado/' WHERE (`SHORT_NAME` = 'TORNADO');
UPDATE `topaz_host` SET `PRIMARY_URL` = 'http://content:9087/' WHERE (`SHORT_NAME` = 'IVR-CALLFLOW');
UPDATE `topaz_host` SET `PRIMARY_URL` = 'http://content:9087/' WHERE (`SHORT_NAME` = 'CAMPAIGN_CONTENT');
UPDATE `topaz_host` SET `PRIMARY_URL` = 'http://optus:9020/' WHERE (`SHORT_NAME` = 'OPTUS-SERVICE');
UPDATE `topaz_host` SET `PRIMARY_URL` = 'http://tokeniser.:8080/' WHERE (`SHORT_NAME` = 'TOKENISER');
UPDATE `topaz_host` SET `PRIMARY_URL` = 'email-smtp.ap-southeast-2.amazonaws.com' WHERE (`SHORT_NAME` = 'SMTP');

UPDATE `topaz_txntype_detail`
SET VALUE='no-reply@dev.afterpaynow.com'
WHERE NAME='OPTUS_PAYMENT_EMAIL';
UPDATE `topaz_txntype_detail`
SET VALUE='no-reply@dev.afterpaynow.com'
WHERE NAME='OPTUS_AUTO_PAY_EMAIL';
UPDATE `topaz_txntype_detail`
SET VALUE='no-reply@dev.afterpaynow.com'
WHERE NAME='BOOST_AUTO_PAY_EMAIL';
UPDATE `topaz_txntype_detail`
SET VALUE='no-reply@dev.afterpaynow.com'
WHERE NAME='BOOST_PAYMENT_EMAIL';
UPDATE `topaz_txntype_detail`
SET VALUE='no-reply@dev.afterpaynow.com'
WHERE NAME='COLES_MOBILE_AUTO_PAY_EMAIL';
UPDATE `topaz_txntype_detail`
SET VALUE='no-reply@dev.afterpaynow.com'
WHERE NAME='COLES_MOBILE_PAYMENT_EMAIL';
UPDATE `topaz_txntype_detail`
SET VALUE='no-reply@dev.afterpaynow.com'
WHERE NAME='GOMO_PAYMENT_EMAIL';
