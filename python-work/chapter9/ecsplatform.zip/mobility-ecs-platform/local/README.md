# Setting up local ECS stack

![](../docs/local-mobility-ecs-platform.png)

We can use a Docker Compose file to gather the current ECS stack.

* Uses a reverse proxy (Traefik) to act as a load balancer
* Reverse proxy control panel is `http://localhost:9090`
* Generates a self-signed `*.localhost` cert for local HTTPS access
* Services are accessible via `https://{service name}.localhost`
* Databases are automagically restored from QA RDS instances dumped into S3 buckets by `.buildkite/export-rds.yaml`
* Database schemas have been merged into one instance for simplicity
* It **should** use Docker images to whatever is present on QA ECS clusters
* We can use the `.env` to abstract values from the Compose file to easily swap out values like image names

```bash
# Login to paynow-dev-admin
saml2aws login -p default --role arn:aws:iam::992517041113:role/paynow-dev-admin

# Login to ECR
saml2aws login -p paynow-buildfactory-admin --role arn:aws:iam::586088138169:role/paynow-buildfactory-admin
    aws ecr get-login-password --profile paynow-buildfactory-admin --region ap-southeast-2 | docker login --username AWS --password-stdin 586088138169.dkr.ecr.ap-southeast-2.amazonaws.com

# Spin up the entire stack!
docker-compose up -d
```

## Development workflow

* Build the service locally with Docker
* Swap out the image name with the locally built image in `.env`
* Run `docker-compose up {service name}` to recreate the service

## Known local development issues

* Docker images need to be manually configured to align to what's in QA
* Topaz requires `default` AWS profile to be logged in - beware, `saml2aws` credentials **expire** every couple hours
* Topaz server takes **~20 minutes** to be ready
* Accessing `https` services will show a browser warning, if Edge or Chrome is being used - type `thisisunsafe` to proceed
* Find a better way to manage SSL certs locally - [Step CA certs](https://github.com/smallstep/certificates)?
