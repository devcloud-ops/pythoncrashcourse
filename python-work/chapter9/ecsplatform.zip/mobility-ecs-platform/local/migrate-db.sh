#!/usr/bin/env bash

set -o pipefail

database_array=(
  "s3://atg-buildkite-artifacts-paynow-qa/exports/rds/pci-cluster-qa/topaz.sql.gz"
  "s3://atg-buildkite-artifacts-paynow-qa/exports/rds/pci-cluster-qa/topaz_extdoc.sql.gz"
  "s3://atg-buildkite-artifacts-paynow-qa/exports/rds/pci-cluster-qa/topaz_secure.sql.gz"
  "s3://atg-buildkite-artifacts-paynow-qa/exports/rds/pci-cluster-qa/topaz_tokeniser.sql.gz"
  "s3://atg-buildkite-artifacts-paynow-qa/exports/rds/non-pci-cluster-qa/topaz_content.sql.gz"
  "s3://atg-buildkite-artifacts-paynow-qa/exports/rds/non-pci-cluster-qa/topaz_sms.sql.gz"
  "s3://atg-buildkite-artifacts-paynow-qa/exports/rds/non-pci-cluster-qa/optus_service.sql.gz"
)

export AWS_REGION=$AWS_DEFAULT_REGION

missing=()

for var in AWS_DEFAULT_REGION DB_HOST DB_USERNAME DB_PASSWORD; do
  if [ -z "${!var}" ]; then
    missing+=("$var")
  fi
done

if [ "${#missing[@]}" -ne 0 ]; then
  for var in "${missing[@]}"; do
    echo -e "\n--: ERROR $var environment variable is required"
  done
  exit 1
fi

while ! mysqladmin ping -h"$DB_HOST" --silent; do
  echo "--: Waiting for MySQL..."
  sleep 1
done

for database in "${database_array[@]}"; do
  aws s3 cp "$database" schema.sql.gz
  gzip -f -d schema.sql.gz

  echo "--: Applying $database"
  mysql -h"$DB_HOST" \
    -u"$DB_USERNAME" \
    -p"$DB_PASSWORD" < schema.sql

  rm -rf schema.sql
  rm -rf schema.sql.gz

  if [ "$?" -ne 0 ]; then
    exit 1
  fi
done

echo "--: Applying ad-hoc migrations"
mysql -h"$DB_HOST" \
  -u"$DB_USERNAME" \
  -p"$DB_PASSWORD" < migrations.sql

if [ "$?" -ne 0 ]; then
  exit 1
fi

echo "--: Done!"
