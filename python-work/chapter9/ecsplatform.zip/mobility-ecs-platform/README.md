# mobility-ecs-platform

[![Build status](https://badge.buildkite.com/482167aadaf95beeb478ffcdd47ec2e73bc27cc8536c08e807.svg)](https://buildkite.com/afterpay-ops/mobility-ecs-platform)

This repository contains the Cloudformation & Terraform templates for provisioning the Mobility Platform.
The Mobility Platform mainly consist of 2 ECS clusters due to the different compliance requirements
for NON-PCI and PCI security standards.

This is a high level diagram of our ECS network including our RDS instances. Applies to all environments.

![Network](docs/mobility-ecs-platform-networking-overview.svg)

## Environments

* [Development](https://apglobal.atlassian.net/l/c/3zdg1ii4)
* [QA](https://apglobal.atlassian.net/l/c/Gj3ciqcG)
* [UAT](https://apglobal.atlassian.net/l/c/kThSiDNQ)
* [Production](https://apglobal.atlassian.net/l/c/wvS7ags0)

## [CloudFormation](./cloudformation)

* VPC
* Load balancers
* Elastic Container Registry images
* MySQL RDS
* Redis cache
* Security groups
* Bastion servers

## [Terraform](./terraform)

* Elastic Container Services
* Load balancer target groups
* ECS IAM
* ECS service discovery + Route53 CNAME routing
* ECS auto-scaling
* Alerting stack

## [Export import databases from on-prem](./bin/export-import-db)

Be able to run scripts to `mysqldump` and restore database from on-prem server to AWS RDS instances.

## [Export import databases from AWS RDS](./bin/migrate-rds)

Be able to run ECS tasks to import/export RDS data from S3 buckets.

## [Local environment via Docker](./local)

Run the ECS platform stack locally with Docker Compose and existing images with database import capabilities.

## AWS environment via CloudFormation

When setting up new AWS environment like: DEV, QA, UAT, or PROD, please ensure of the following:

* Populate the following under `AWS Systems Manager --> Parameter Store`
  * `/paynow/mobility/{compliance}/database/masterusername`
  * `/paynow/mobility/{compliance}/database/masterpassword`
  * `/paynow/mobility/{compliance}/svc-topaz/keystore/password`
  * `/paynow/mobility/{compliance}/svc-topaz/newrelic/api-key`
  * `/paynow/mobility/{compliance}/svc-topaz/newrelic/license`
* Generate target environment's EC2 Key Pair under `AWS EC2 --> Key Pairs` for Bastion 
* Ensure that there aren't any comments in the config files
* Generate target environment's Hosted zones under `AWS --> Route 53`. Ensure that this zone's NS records are handled in Cloudflare repo.
* Ensure that NAT gateway limit of 5 isn't reached. If it is, get it increased via AWS support.
* Ensure that after every unsuccessful Cloudformation run, S3 bucket: `{compliance}-vpc-access-logs` is manually deleted.
* Locate the keystore binary file with extension `.jks` in the respective environment's Topaz server and upload it to the AWS Secrets Manager after creating an empty file there.
  * `/paynow/mobility/{compliance}/svc-topaz/keystore`

## Alerting

![](./docs/mobility-alerts.png)

Alerting infrastructure is partially deployed via code at `terraform/alerting` with Buildkite.

### AWS Bot

* Use to visualise CloudWatch graphs
* Diagnose logs
* Manual
  * SNS HTTPS subscription needs to assigned to the topic on AWS Console
  * [Slack integration](https://afterpaytouch.slack.com/apps/A6L22LZNH-aws-chatbot) - [guide](https://docs.aws.amazon.com/chatbot/latest/adminguide/getting-started.html)

### VictorOps

* Manual
  * Adding team members
  * Assigning members to rotations
  * [Slack integration](https://portal.victorops.com/dash/touchcorp#/advanced/slack2) - [guide](https://help.victorops.com/knowledge-base/slack-integration-guide/)
* Terraform
  * Route keys - [guide](https://help.victorops.com/knowledge-base/routing-keys/)
  * Team
  * Escalation policy - [guide](https://help.victorops.com/knowledge-base/team-escalation-policy/)
  * SNS via CloudWatch integration - [guide](https://help.victorops.com/knowledge-base/aws-cloudwatch-integration-guide/)

## VPN Connectivity

This applies to the UAT connectivity. It will be available for the first phase of the migration and will be torn down once we're out of the data centre. Ideally, we'll get Optus to point to the new payment API.

### Production

![prod-vpn](docs/mobility-ecs-platform-networking-prod-vpn-connectivity.svg)

### UAT

![uat-vpn](docs/mobility-ecs-platform-networking-uat-vpn-connectivity.svg)
