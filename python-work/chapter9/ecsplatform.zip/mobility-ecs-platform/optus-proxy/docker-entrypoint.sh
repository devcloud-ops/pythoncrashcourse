#!/bin/sh

set -o errexit
set -o nounset

main() {
  start_lb "$@"
}

start_lb() {
  export AWS_ENV=${AWS_ENV}
  export DOCKERIP="$(hostname -i)"
  export DNS_ADDR=$(cat /etc/resolv.conf|grep nameserver|awk '{print$NF}')
  haproxy -vv
  echo haproxy -W -db "$@"
  exec haproxy -W -db "$@"
}

main "$@"
